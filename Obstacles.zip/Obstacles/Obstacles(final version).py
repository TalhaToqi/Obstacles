import pygame
import sys
import random
import cv2
import mediapipe as mp
import numpy as np

# Initialize MediaPipe for hand tracking
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)
mp_drawing = mp.solutions.drawing_utils

# Pygame Initialization
init_status = pygame.init()
if init_status[1] > 0:
    print(f"(!) Had {init_status[1]} initializing errors, exiting...")
    sys.exit()
else:
    print("(+) Pygame initialized successfully")

# Game Settings
width, height = 640, 480
gameDisplay = pygame.display.set_mode((width, height))
pygame.display.set_caption("Dodge It!")
clock = pygame.time.Clock()

# Colors
black = (0, 0, 0)
white = (255, 255, 255)
bright_red = (255, 0, 0)
bright_green = (0, 255, 0)
red = (200, 0, 0)
green = (0, 200, 0)
pause = False

try:
    # Load images
    carImg = pygame.image.load("media\\car.png")
    carRect = carImg.get_rect()
    car_w = carRect.width
    car_h = carRect.height
    road_bg = pygame.image.load("media\\road_background.png")
    road_bg = pygame.transform.scale(road_bg, (width, height))
    obstacle_img = pygame.image.load("media\\barricade.png")
    obstacle_img = pygame.transform.scale(obstacle_img, (80, 80))
except Exception as e:
    print(f"Error loading images: {e}")
    sys.exit()

# Webcam feed for gesture detection
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    sys.exit()

# Variables for road background scrolling
bg_y1 = 0
bg_y2 = -height
bg_speed = 5

# Function Definitions
def car(x, y):
    gameDisplay.blit(carImg, (x, y))

def block(blockx, blocky):
    gameDisplay.blit(obstacle_img, (blockx, blocky))

def message(text, textSize, textColor, textCenterPos):
    textFont = pygame.font.Font(None, textSize)
    textSurf = textFont.render(text, True, textColor)
    textRect = textSurf.get_rect()
    textRect.center = textCenterPos
    gameDisplay.blit(textSurf, textRect)

# Gesture Detection Function
def detect_gesture(hand_landmarks):
    thumb_is_open = False
    index_is_open = False

    # Get landmark coordinates
    landmarks = hand_landmarks.landmark

    # Thumb: Tip (4), IP (3), MCP (2), CMC (1)
    thumb_tip_y = landmarks[4].y
    thumb_ip_y = landmarks[3].y

    # Index Finger: Tip (8), PIP (6), MCP (5)
    index_tip_y = landmarks[8].y
    index_pip_y = landmarks[6].y

    # Check if thumb is up
    if thumb_tip_y < thumb_ip_y:
        thumb_is_open = True

    # Check if index finger is up
    if index_tip_y < index_pip_y:
        index_is_open = True

    if thumb_is_open and not index_is_open:
        return 'LEFT'
    elif index_is_open and not thumb_is_open:
        return 'RIGHT'
    else:
        return 'STRAIGHT'

# Main Game Loop
def gameloop():
    global pause, bg_y1, bg_y2
    car_x = width * 0.45
    car_y = height * 0.8
    block_x = random.randrange(0, width - 80)
    block_y = -800
    block_speed = 5
    score = 0

    while True:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quitgame()

        # Move road background
        bg_y1 += bg_speed
        bg_y2 += bg_speed
        if bg_y1 >= height:
            bg_y1 = -height
        if bg_y2 >= height:
            bg_y2 = -height

        # Read frame from webcam
        ret, frame = cap.read()
        if not ret:
            print("Error: Webcam frame not read.")
            continue

        frame = cv2.flip(frame, 1)
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(image_rgb)

        # Detect gestures and apply actions
        gesture = 'STRAIGHT'
        if result.multi_hand_landmarks:
            for hand_landmarks in result.multi_hand_landmarks:
                gesture = detect_gesture(hand_landmarks)
                # Draw hand landmarks on the frame
                mp_drawing.draw_landmarks(
                    frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # Control car based on gesture
        if gesture == 'LEFT' and car_x > 0:
            car_x -= 5  # Move car to the left
        elif gesture == 'RIGHT' and car_x < width - car_w:
            car_x += 5  # Move car to the right
        # If 'STRAIGHT', do not move the car horizontally

        # Update obstacle position
        block_y += block_speed

        # Respawn obstacle if it goes off-screen
        if block_y > height:
            block_y = -80
            block_x = random.randrange(0, width - 80)
            score += 1  # Increase score

        # Check for collision
        if car_y < block_y + 80:
            if (car_x > block_x and car_x < block_x + 80) or (car_x + car_w > block_x and car_x + car_w < block_x + 80):
                crash()

        # Draw background, car, and obstacles
        gameDisplay.blit(road_bg, (0, bg_y1))
        gameDisplay.blit(road_bg, (0, bg_y2))
        car(car_x, car_y)
        block(block_x, block_y)
        message(f"Score: {score}", 24, white, (70, 30))

        # Update screen
        pygame.display.update()

        # Show webcam feed with hand landmarks
        cv2.imshow('MediaPipe Hands', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            quitgame()

    cap.release()
    cv2.destroyAllWindows()

# Crash function
def crash():
    message("You Crashed!", 64, bright_red, (width / 2, height / 2))
    pygame.display.update()
    pygame.time.wait(2000)
    gameloop()  # Restart the game

# Quit game function
def quitgame():
    cap.release()
    cv2.destroyAllWindows()
    pygame.quit()
    sys.exit()

# Start Game
try:
    gameloop()
except Exception as e:
    print(f"Game error: {e}")
    quitgame()
